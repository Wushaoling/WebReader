// ocxAppCtrl.cpp : CocxAppCtrl ActiveX �ؼ����ʵ�֡�

#include "stdafx.h"
#include "ocxApp.h"
#include "ocxAppCtrl.h"
#include "ocxAppPropPage.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNCREATE(CocxAppCtrl, COleControl)

// ��Ϣӳ��
BEGIN_MESSAGE_MAP(CocxAppCtrl, COleControl)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

// ����ӳ��
BEGIN_DISPATCH_MAP(CocxAppCtrl, COleControl)
	DISP_FUNCTION_ID(CocxAppCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CocxAppCtrl, "GetString", DISPID_GETSTRING, GetString, VT_BSTR, VTS_I4)
	DISP_FUNCTION_ID(CocxAppCtrl, "SetString", DISPID_SETSTRING, SetString, VT_BOOL, VTS_BSTR)
END_DISPATCH_MAP()

// �¼�ӳ��
//	�¼�������
BEGIN_EVENT_MAP(CocxAppCtrl, COleControl)
	//EVENT_CUSTOM_ID("stringEnter", eventidstringEnter, stringEnter, VTS_NONE)
	//EVENT_CUSTOM_ID("PrintString", eventidPrintString, PrintString, VTS_BSTR)
	EVENT_CUSTOM_ID("ClickIn", eventidClickIn, FireClickIn, VTS_XPOS_PIXELS VTS_YPOS_PIXELS)
	EVENT_CUSTOM_ID("OnMyEvent", eventidOnMyEvent, FireOnMyEvent, VTS_I4)
	EVENT_CUSTOM_ID("PressMe", eventidPressMe, PressMe, VTS_NONE)
	EVENT_CUSTOM_ID("OneParamEvent", eventidOneParamEvent, OneParamEvent, VTS_BSTR)
END_EVENT_MAP()

// ����ҳ
BEGIN_PROPPAGEIDS(CocxAppCtrl, 1)
	PROPPAGEID(CocxAppPropPage::guid)
END_PROPPAGEIDS(CocxAppCtrl)



// ��ʼ���๤���� guid

IMPLEMENT_OLECREATE_EX(CocxAppCtrl, "OCXAPP.ocxAppCtrl.1",
	0xdb87c40e, 0x424, 0x41d8, 0xad, 0x9c, 0x3, 0x8, 0x4a, 0x60, 0xe3, 0xb7)



// ����� ID �Ͱ汾

IMPLEMENT_OLETYPELIB(CocxAppCtrl, _tlid, _wVerMajor, _wVerMinor)



// �ӿ� ID

const IID BASED_CODE IID_DocxApp =
		{ 0x11C8E0F1, 0xDD6C, 0x4189, { 0x88, 0x1B, 0x87, 0x98, 0xED, 0x9E, 0xF4, 0xC8 } };
const IID BASED_CODE IID_DocxAppEvents =
		{ 0x824EC8B, 0x64, 0x4BD2, { 0xB5, 0xDD, 0xEB, 0xD2, 0x14, 0x29, 0xFD, 0x66 } };



// �ؼ�������Ϣ

static const DWORD BASED_CODE _dwocxAppOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CocxAppCtrl, IDS_OCXAPP, _dwocxAppOleMisc)


BOOL CocxAppCtrl::CocxAppCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_OCXAPP,
			IDB_OCXAPP,
			afxRegApartmentThreading,
			_dwocxAppOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}

//�ٽ�������
CRITICAL_SECTION cs;
//������
static char PosBuf[100];
//��ȡ�ܵ��ĺ���
DWORD WINAPI FunReadPipe(LPVOID lpParamter)
{
	HANDLE h;
	const char* pipename = "\\\\.\\pipe\\testpipe"; //�ܵ�����Ҫ����������һ��
	//�ȴ���������ܵ����ã�ȷ���������Ѿ�����
	if (WaitNamedPipe(_T("\\\\.\\pipe\\testpipe"), NMPWAIT_WAIT_FOREVER) == FALSE){
		//cout << "�������з�������" << endl;
		return 1;
	}
	//�򿪹ܵ��ļ��Ա��д��ʵ�������ӵ������ܵ�����������
	h = CreateFile(_T("\\\\.\\pipe\\testpipe"), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING,
		FILE_ATTRIBUTE_ARCHIVE | FILE_FLAG_WRITE_THROUGH, NULL);
	if (h != INVALID_HANDLE_VALUE){
		//char buf[100];
		DWORD len;
		while (1) {
			char buf[100];
			
			if (ReadFile(h, buf, 100, &len, NULL)){//�ܵ����ӳɹ����ӹܵ���ȡ����
				buf[len] = '\0';//�����ַ���������־�������ȡ��������
				//�ٽ�����ʼ
				EnterCriticalSection(&cs);
				for (int i = 0; i <= len; i++) {
					PosBuf[i] = buf[i];
				}
				//�ٽ�������
				LeaveCriticalSection(&cs);
			}
		}
		CloseHandle(h);//�رչܵ�����
	}
}
CocxAppCtrl::CocxAppCtrl()
{
	InitializeIIDs(&IID_DocxApp, &IID_DocxAppEvents);

	//��ʼ���ٽ���
	InitializeCriticalSection(&cs);
	//�����ܵ���ȡ�߳�
	HANDLE hThread = CreateThread(NULL, 0, FunReadPipe, NULL, 0, NULL);
	
}

CocxAppCtrl::~CocxAppCtrl()
{
	// �����ٽ���
	DeleteCriticalSection(&cs);
}

void CocxAppCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	if (!pdc)
		return;

	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
 	pdc->Ellipse(rcBounds);
	// left top right bottom

	if (m_string != "")
	{
		CRect mtRect(40, 300, 200, 400);
		pdc->FillSolidRect(&mtRect, RGB(231, 0, 229)) ;
		pdc->SetTextColor(GetSysColor(COLOR_WINDOWTEXT));
		pdc->DrawText(m_string, mtRect,DT_WORDBREAK|DT_CENTER);
	}
}

void CocxAppCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);
}

void CocxAppCtrl::OnResetState()
{
	COleControl::OnResetState();  
}

void CocxAppCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_OCXAPP);
	dlgAbout.DoModal();
}



BSTR CocxAppCtrl::GetString(int Method)
{
	wchar_t WideString[120]; 
	char *ReturnString;
	
	ReturnString = new char[100];
	//�ٽ�����ʼ
	EnterCriticalSection(&cs);
	for (int i = 0; i < 100; i++)
	{
		ReturnString[i] = PosBuf[i];
		if (PosBuf[i] == '\0')
			break;
	}
	//�ٽ�������
	LeaveCriticalSection(&cs);
	if (MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, ReturnString, -1, WideString, 120) == 0)
		return NULL;
	return (BSTR)SysAllocString(WideString);
}

boolean CocxAppCtrl::SetString( LPCTSTR string )
{
	m_string = string;

	UpdateData(TRUE);
	Invalidate();

	return true;
}
void CocxAppCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	//FireOnMyEvent(point.x); 
	
	CRect rect;
	GetWindowRect(&rect);

	if (rect.PtInRect(point))
	{
		// PrintString(_T("Hello") );
		FireClickIn(point.x, point.y);
		CString info;
		info.Format(_T("�ؼ����������λ��: %d %d"), point.x, point.y);
		OneParamEvent( info );
	}

	COleControl::OnLButtonDown(nFlags, point);
}
