

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sat Nov 05 20:03:02 2016
 */
/* Compiler settings for ocxApp.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, LIBID_ocxAppLib,0x60E39CD5,0x3611,0x4BAF,0xBA,0x41,0x4E,0xF0,0x38,0x8E,0xD3,0xD4);


MIDL_DEFINE_GUID(IID, DIID__DocxApp,0x11C8E0F1,0xDD6C,0x4189,0x88,0x1B,0x87,0x98,0xED,0x9E,0xF4,0xC8);


MIDL_DEFINE_GUID(IID, DIID__DocxAppEvents,0x0824EC8B,0x0064,0x4BD2,0xB5,0xDD,0xEB,0xD2,0x14,0x29,0xFD,0x66);


MIDL_DEFINE_GUID(CLSID, CLSID_ocxApp,0xDB87C40E,0x0424,0x41D8,0xAD,0x9C,0x03,0x08,0x4A,0x60,0xE3,0xB7);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



